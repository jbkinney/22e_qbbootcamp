### Scripts ###

source elzar_modules.sh -- Load all modules required by the tools.
./clean.sh -- Cleans out all analysis files from area
./map_one_sample.sh -- Maps reads in one file to the yeast genome and creates bed pileups
./map_all_samples.sh -- Maps reads in 4 files to the yeast genome and creates bed pileups

### Input files ###

./genome/
	genome.fastq   # Yeast genome

./reads/
	A1.fastq  B1.fastq  C1.fastq  D1.fastq   # 4 read files
	
### Dependencies ###

./code/pileup2bedfile.py -- Creates bed file from samtools pileup file

